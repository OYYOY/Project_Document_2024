clear all
clc
close all
%% Simulink Parameter
f0 = 85e3;
w0 = 2*pi*f0;
Tsim = 1/f0/1000;
%% System Parameter
Vin = 200;
RL = 20;

U_diode = 1.7;
Cout = 470e-6;

f1 = f0;
w1 = 2*pi*f0;
%% Inductance Parameter
LF = 17.70e-6;
LT = 74.25e-6;
LR = 74.23e-6;

RF = w1*LF/300;
RT = w1*LT/300;
RR = w1*LR/300;

MTR = 23.13e-6;
%% Capacitance Parameter
CF = 1/w1^2/LF;
CT = 1/w1^2/LT;
CR = 1/w1^2/LR;
%%  Output Calculation Result
UT = 2*sqrt(2)*Vin/pi;
REQ = 8*RL/pi/pi;

% 当S1导通时，此时补偿网络为S-S
IT_1 = abs(-UT*(RR + REQ)/(MTR^2*i^2*w1^2 - REQ*RT - RR*RT)),
IR_1 = abs(-MTR*UT*i*w1/(MTR^2*i^2*w1^2 - REQ*RT - RR*RT)), 

UR_1 = REQ*IR_1-2*U_diode;
Vout_1 = UR_1*pi/2/sqrt(2),
Iout_1 = IR_1*2*sqrt(2)/pi,

Pout_1 = UR_1*IR_1,
Pin_1 = IT_1^2*RT+IR_1^2*RR+Pout_1,
Eff_1 = Pout_1/Pin_1,
% 当S2导通时，此时补偿网络为LCC-S
IF_2 = abs(UT*(MTR^2*i^2*w1^2 - REQ*RF - REQ*RT - RF*RR - RR*RT)/(LF^2*REQ*i^2*w1^2 + LF^2*RR*i^2*w1^2 + MTR^2*RF*i^2*w1^2 - REQ*RF^2 - REQ*RF*RT - RF^2*RR - RF*RR*RT)),
IR_2 = abs(i^2*w1^2*MTR*LF*UT/(LF^2*REQ*i^2*w1^2 + LF^2*RR*i^2*w1^2 + MTR^2*RF*i^2*w1^2 - REQ*RF^2 - REQ*RF*RT - RF^2*RR - RF*RR*RT)), 
IT_2 = abs(LF*UT*i*w1*(RR + REQ)/(LF^2*REQ*i^2*w1^2 + LF^2*RR*i^2*w1^2 + MTR^2*RF*i^2*w1^2 - REQ*RF^2 - REQ*RF*RT - RF^2*RR - RF*RR*RT)),

UR_2 = REQ*IR_2-2*U_diode;
Vout_2 = UR_2*pi/2/sqrt(2),
Iout_2 = IR_2*2*sqrt(2)/pi,

Pout_2 = UR_2*IR_2,
Pin_2 = IF_2^2*RF+IT_2^2*RT+IR_2^2*RR+Pout_2,
Eff_2 = Pout_2/Pin_2,